Video links:
	Persistent backdoor: https://youtu.be/y6T4NukQveA
	Encrypt & delete files: https://youtu.be/vT0So0oQaCI
	Install browser extension: https://youtu.be/NRiTemhRocY

1. I did not use GPG to encrypt files, instead I added them into a large zip file and put a password on it
2. The password is "superpass"
3. There's no need to export any keys since no GPG is involved
4. In order to add an extension, Terminal app has to be given Accessibility permission prior to the attack. Some machines may have given Accessibility permission to Terminal app, but most machines will not have. This is the only uncertainty during the attack.